package com.tvplayer.app.skipdetection;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import androidx.media3.common.Player;

import com.tvplayer.app.PreferencesHelper;
// # Import the new audio strategy
import com.tvplayer.app.skipdetection.strategies.AudioFingerprintStrategy; 
import com.tvplayer.app.skipdetection.strategies.CacheStrategy;
import com.tvplayer.app.skipdetection.strategies.ChapterStrategy;
import com.tvplayer.app.skipdetection.strategies.IntroHaterStrategy;
import com.tvplayer.app.skipdetection.strategies.IntroSkipperStrategy;
import com.tvplayer.app.skipdetection.strategies.ManualPreferenceStrategy;
import com.tvplayer.app.skipdetection.strategies.MetadataHeuristicStrategy;

// # FIX: Added this import to resolve the 'cannot find symbol: variable DetectionSource' error
import com.tvplayer.app.skipdetection.SkipDetectionResult.DetectionSource;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

/**
 * SmartSkipManager
 * FUNCTION: Coordinates all skip detection strategies using a tiered priority system.
 *           Cache is checked first, then all strategies run concurrently, and the
 *           best result is selected based on TIER (priority) first, then confidence.
 * INTERACTS WITH: All *Strategy.java files, MainActivity.java, PreferencesHelper.java.
 * 
 * PRIORITY TIERS (Reliability Levels):
 *   - Tier 600: Cache (checked synchronously before other strategies)
 *   - Tier 500: Chapter Markers & Metadata Heuristics (most reliable)
 *   - Tier 400: Community APIs (IntroSkipper, IntroHater) (moderately reliable)
 *   - Tier 300: Audio Fingerprinting (when implemented)
 *   - Tier 100: Manual User Preferences (final failsafe)
 * 
 * SELECTION LOGIC:
 *   1. Higher tier (priority) always wins over lower tier, regardless of confidence
 *   2. Within same tier, highest confidence wins
 *   3. Manual preferences only surface when all higher tiers fail
 * 
 * FIXED: Tiered priority system ensures reliable strategies are preferred over
 *        manual fallbacks, and metadata strategies have time to populate.
 * 
 * PERSONALIZATION:
 * - DETECTION_TIMEOUT_MS: Max wait time for strategies (default 10 seconds).
 * - METADATA_WAIT_MS: Additional wait for chapter metadata to populate (default 2 seconds).
 * - EXECUTOR_THREADS: Number of concurrent strategy executions.
 */
public class SmartSkipManager {

    private static final String TAG = "SmartSkipManager";
    // # Max time (10 seconds) to wait for all strategies to finish.
    private static final int DETECTION_TIMEOUT_MS = 10000;
    // # Additional wait time for metadata-driven strategies (e.g., chapters) to populate
    private static final int METADATA_WAIT_MS = 2000;
    // # Number of strategies to run at the same time.
    private static final int EXECUTOR_THREADS = 4;

    private final PreferencesHelper prefsHelper;
    private final ExecutorService executorService; 
    private final Handler mainHandler;
    private final CacheStrategy cacheStrategy;
    private final List<SkipDetectionStrategy> strategies;

    // # Special reference to ChapterStrategy so we can rebind the player
    private final ChapterStrategy chapterStrategy;

    /**
     * Constructor
     * FUNCTION: Initializes all strategies and sorts them by priority.
     * FIX: No longer takes a Player object to fix the startup build error.
     */
    public SmartSkipManager(Context context, PreferencesHelper prefsHelper) {
        this.prefsHelper = prefsHelper;
        this.executorService = Executors.newFixedThreadPool(EXECUTOR_THREADS);
        this.mainHandler = new Handler(Looper.getMainLooper());

        // # Initialize CacheStrategy (which is run separately)
        this.cacheStrategy = new CacheStrategy(context);

        // # Initialize all detection strategies
        this.strategies = new ArrayList<>();

        // # Create the ChapterStrategy instance (it's player-less for now)
        this.chapterStrategy = new ChapterStrategy();

        // # Add all strategies to the list
        // # NOTE: All strategies run CONCURRENTLY, not sequentially
        // # Priority determines which result wins when multiple strategies succeed
        // # Higher tier (priority number) always beats lower tier regardless of confidence
        
        // # Tier 100: Manual User Preferences (lowest tier - final failsafe)
        this.strategies.add(new ManualPreferenceStrategy(prefsHelper));
        
        // # Tier 300: Audio Fingerprinting (currently not implemented)
        this.strategies.add(new AudioFingerprintStrategy()); 
        
        // # Tier 400: Community APIs (moderately reliable)
        this.strategies.add(new IntroHaterStrategy());
        this.strategies.add(new IntroSkipperStrategy());
        
        // # Tier 500: Chapter Markers & Metadata (highest tier - most reliable)
        this.strategies.add(new MetadataHeuristicStrategy(prefsHelper));
        this.strategies.add(this.chapterStrategy); // # Add the instance we saved

        // # Sort strategies by priority (highest number first) for logging
        // # IMPORTANT: This sort order is just for display/logging
        // # The actual winner is determined by tier-aware selection logic in the concurrent section
        Collections.sort(this.strategies, Comparator.comparingInt(SkipDetectionStrategy::getPriority).reversed());

        // # Log the final sorted order for debugging
        Log.i(TAG, "SmartSkipManager initialized. Strategy Priority Order:");
        for (int i = 0; i < this.strategies.size(); i++) {
            SkipDetectionStrategy s = this.strategies.get(i);
            Log.i(TAG, String.format("  #%d: %s (Priority=%d)", i + 1, s.getStrategyName(), s.getPriority()));
        }
    }

    /**
     * rebindPlayer
     * FUNCTION: Binds the player to strategies that need it (like ChapterStrategy).
     * This is called from MainActivity once the player is in the STATE_READY.
     * @param player The prepared Media3 Player instance.
     */
    public void rebindPlayer(Player player) {
        // # Pass the player to the chapter strategy
        if (chapterStrategy != null) {
            chapterStrategy.rebindToPlayer(player);
        }
    }

    /**
     * detectSkipSegmentsAsync
     * FUNCTION: Starts the detection process on a background thread.
     * @param mediaIdentifier Input data for the strategies.
     * @param callback The interface to return the result to (MainActivity).
     */
    public void detectSkipSegmentsAsync(MediaIdentifier mediaIdentifier, SkipDetectionCallback callback) {
        // # Run the entire detection logic on a background thread
        executorService.submit(() -> {
            SkipDetectionResult result = detectSkipSegmentsSync(mediaIdentifier);

            // # Post the final result back to the main UI thread
            mainHandler.post(() -> {
                if (result.isSuccess()) {
                    callback.onDetectionComplete(result);
                } else {
                    callback.onDetectionFailed(result.getErrorMessage());
                }
            });
        });
    }

    /**
     * detectSkipSegmentsSync
     * FUNCTION: The core, synchronous (blocking) detection logic.
     * This runs on the background thread.
     */
    private SkipDetectionResult detectSkipSegmentsSync(MediaIdentifier mediaIdentifier) {

        // # 1. Check Cache First
        SkipDetectionResult cachedResult = cacheStrategy.detect(mediaIdentifier);
        if (cachedResult.isSuccess()) {
            Log.i(TAG, "Cache hit: Returning result from " + cachedResult.getSource().getDisplayName());
            return cachedResult;
        }
        Log.i(TAG, "Cache miss. Starting fresh detection.");

        // # Clear any old chapter data before starting
        chapterStrategy.clearCapturedChapters();

        // # Variables to hold the best result and its strategy priority
        final AtomicReference<SkipDetectionResult> bestResult = new AtomicReference<>(null);
        final AtomicReference<Integer> bestPriority = new AtomicReference<>(0);
        final List<Future<?>> futures = new ArrayList<>();

        // # 2. Run all strategies concurrently
        for (SkipDetectionStrategy strategy : strategies) {
            if (!strategy.isAvailable()) {
                Log.d(TAG, "Skipping unavailable strategy: " + strategy.getStrategyName());
                continue; 
            }

            // # Submit each strategy to be run on the thread pool
            Future<?> future = executorService.submit(() -> {
                try {
                    Log.d(TAG, "Starting detection: " + strategy.getStrategyName());
                    SkipDetectionResult result = strategy.detect(mediaIdentifier);

                    if (result.isSuccess()) {
                        int strategyPriority = strategy.getPriority();
                        Log.i(TAG, "Success from " + strategy.getStrategyName() + 
                              " (Tier: " + strategyPriority + ", Conf: " + result.getConfidence() + ")");

                        // # Critical Section: Only one thread can update the best result
                        synchronized (bestResult) {
                            SkipDetectionResult current = bestResult.get();
                            Integer currentPriority = bestPriority.get();
                            
                            // # TIERED SELECTION LOGIC:
                            // # 1. If no result yet, use this one
                            // # 2. If new strategy has HIGHER tier (priority), it wins regardless of confidence
                            // # 3. If same tier, higher confidence wins
                            boolean shouldReplace = false;
                            
                            if (current == null) {
                                shouldReplace = true;
                            } else if (strategyPriority > currentPriority) {
                                // # Higher tier always wins
                                shouldReplace = true;
                                Log.i(TAG, "Higher tier wins: " + strategy.getStrategyName() + 
                                      " (Tier " + strategyPriority + ") beats (Tier " + currentPriority + ")");
                            } else if (strategyPriority == currentPriority && 
                                      result.getConfidence() > current.getConfidence()) {
                                // # Same tier, higher confidence wins
                                shouldReplace = true;
                                Log.i(TAG, "Same tier, higher confidence wins: " + strategy.getStrategyName());
                            }
                            
                            if (shouldReplace) {
                                bestResult.set(result);
                                bestPriority.set(strategyPriority);
                                Log.i(TAG, "New best result set by " + strategy.getStrategyName());
                            }
                        }
                    } else {
                         Log.d(TAG, "Failed: " + strategy.getStrategyName() + " (" + result.getErrorMessage() + ")");
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Error in strategy " + strategy.getStrategyName(), e);
                }
            });

            futures.add(future);
        }

        // # 3. Wait for all threads to complete or timeout
        long startTime = System.currentTimeMillis();
        boolean allDone = false;
        while (!allDone && (System.currentTimeMillis() - startTime) < DETECTION_TIMEOUT_MS) {
            allDone = true;
            for (Future<?> future : futures) {
                if (!future.isDone()) {
                    allDone = false;
                    break;
                }
            }
            if (!allDone) {
                try {
                    Thread.sleep(100); // # Wait 100ms before checking again
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
        }

        // # 4. Cancel any remaining running threads (if timeout was hit)
        if (!allDone) {
            Log.w(TAG, "Detection timed out. Cancelling remaining strategies.");
            for (Future<?> future : futures) {
                if (!future.isDone()) {
                    future.cancel(true); // # Interrupt the running thread
                }
            }
        }

        // # 5. Final Result Determination with Tiered Priority System
        // # FIX: Select winner based on TIER (priority) first, then confidence
        SkipDetectionResult finalResult = selectBestResultByTier(bestResult.get());

        // # If no strategy succeeded, create a 'failed' result
        if (finalResult == null) {
            Log.w(TAG, "No strategy returned a successful result.");
            // # FIX: This line now compiles due to the new import
            finalResult = SkipDetectionResult.failed(DetectionSource.NONE, "No skip segments found by any strategy.");
        }

        // # 6. Cache the best result (even if it's a 'failed' result)
        cacheStrategy.cacheResult(mediaIdentifier, finalResult);

        return finalResult;
    }

    /**
     * selectBestResultByTier
     * FUNCTION: Pass-through method - tier selection now happens in concurrent section.
     * FIX: The tiered selection logic has been moved to the concurrent execution loop
     *      where each result is compared by tier first, then confidence.
     * 
     * @param currentBest The result selected by tier-aware logic
     * @return The final result (already tier-selected)
     */
    private SkipDetectionResult selectBestResultByTier(SkipDetectionResult currentBest) {
        // # The tier-based selection now happens in the concurrent section above,
        // # so this method just passes through the already-selected best result.
        return currentBest;
    }

    // # Public methods for cache management from Settings
    public void clearCache() {
        cacheStrategy.clearCache();
    }

    public void invalidateCache(MediaIdentifier mediaIdentifier) {
        cacheStrategy.invalidateCache(mediaIdentifier);
    }

    // # Clean shutdown of the thread pool
    public void shutdown() {
        executorService.shutdownNow();
    }
}